cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
  {
    "id": "nlscan-plugin-barcodescanner.BarcodeScanner",
    "file": "plugins/nlscan-plugin-barcodescanner/www/BarcodeScanner.js",
    "pluginId": "nlscan-plugin-barcodescanner",
    "clobbers": [
      "nlscan.plugins.barcodescanner"
    ]
  },
  {
    "id": "cordova-plugin-statusbar.statusbar",
    "file": "plugins/cordova-plugin-statusbar/www/statusbar.js",
    "pluginId": "cordova-plugin-statusbar",
    "clobbers": [
      "window.StatusBar"
    ]
  }
];
module.exports.metadata = 
// TOP OF METADATA
{
  "cordova-plugin-whitelist": "1.3.3",
  "nlscan-plugin-barcodescanner": "0.0.1",
  "cordova-plugin-statusbar": "2.4.1"
};
// BOTTOM OF METADATA
});