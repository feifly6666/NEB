package com.nlscan.cordova.plugin.barcodescanner;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.json.JSONArray;
import org.json.JSONException;

/**
 * Cordova plugin to interface with NLSCAN barcode scanners.
 * auth:Alan
 * 20180101
 * Nlscan
 */
public class BarcodeScanner extends CordovaPlugin {


    private Context context;

    private static final String SCANNER_TRIG = "nlscan.action.SCANNER_TRIG";
    private static final String EXTRA_SCAN_POWER = "EXTRA_SCAN_POWER";
    public static final String ACTION_BAR_SCANCFG = "ACTION_BAR_SCANCFG";
    private static final String Tag = "BarcodeScannerTag";

    private Activity activity;

    @Override
    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
        super.initialize(cordova, webView);
        context = super.webView.getContext();
        this.activity = cordova.getActivity();

    }


    @Override
    public boolean execute(String action, JSONArray para, CallbackContext callbackContext) throws JSONException {
        if (action.equals("scan")) {
            Log.d(Tag, "execute method is called");
            Intent intent = new Intent(SCANNER_TRIG);
            context.sendBroadcast(intent);
            callbackContext.success();
            return true;
        } else if (action.equals("scanSetting")) {
            Log.d(Tag, "Action:" + para.getString(0) + " Para:" + para.getString(1));
            Intent intent = new Intent(ACTION_BAR_SCANCFG);
            intent.putExtra(para.getString(0), Integer.parseInt(para.getString(1)));
            context.sendBroadcast(intent);
            callbackContext.success();
            return true;

        }
        return false;
    }
}









