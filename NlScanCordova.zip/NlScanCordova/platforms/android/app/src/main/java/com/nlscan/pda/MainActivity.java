/*
       Licensed to the Apache Software Foundation (ASF) under one
       or more contributor license agreements.  See the NOTICE file
       distributed with this work for additional information
       regarding copyright ownership.  The ASF licenses this file
       to you under the Apache License, Version 2.0 (the
       "License"); you may not use this file except in compliance
       with the License.  You may obtain a copy of the License at

         http://www.apache.org/licenses/LICENSE-2.0

       Unless required by applicable law or agreed to in writing,
       software distributed under the License is distributed on an
       "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
       KIND, either express or implied.  See the License for the
       specific language governing permissions and limitations
       under the License.
 */

package com.nlscan.pda;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;

import com.nlscan.nquireprogramservice.IFrameworkAidlInterface;

import org.apache.cordova.CordovaActivity;

/**
 * @author Alan
 * @Company nlscan
 * @date 2018/3/2 11:55
 * @Description:MainActivity
 */
public class MainActivity extends CordovaActivity {

    private final String LOGCAT_TAG = "BarcodeScannerTag";
    private IFrameworkAidlInterface frameworkAidlInterface = null;
    private static final String SCANNER_RESULT = "nlscan.action.SCANNER_RESULT";
    private static final String CONNECTIVITY_CHANGE = "android.net.conn.CONNECTIVITY_CHANGE";
    private static boolean scanResultBroadcastFlag = false;
    private static boolean netLinkBroadcastFlag = false;
    private ConnectivityManager connectivityManager = null;
    private SparseArray<NetLinkStatusReceiver.NqNetType> nqNetTypeMap = new SparseArray<>(3);

    private NetLinkStatusReceiver.NqNetType lastConnectedNetType = NetLinkStatusReceiver.NqNetType.NONE;
    {
        nqNetTypeMap.put(ConnectivityManager.TYPE_ETHERNET, NetLinkStatusReceiver.NqNetType.ETHERNET);
        nqNetTypeMap.put(ConnectivityManager.TYPE_WIFI, NetLinkStatusReceiver.NqNetType.WIFI);
        //nqNetTypeMap.put(ConnectivityManager.TYPE_MOBILE, NqNetType.MOBILE);
    }

    private ServiceConnection frameworkServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.d(LOGCAT_TAG, "frameworkServiceConnection onServiceConnected");
            frameworkAidlInterface = IFrameworkAidlInterface.Stub.asInterface(service);
            enablePersistentImmersiveMode(true);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.d(LOGCAT_TAG, "frameworkServiceConnection onServiceDisconnected");
            frameworkAidlInterface = null;
        }
    };


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // enable Cordova apps to be started in the background
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.getBoolean("cdvStartInBackground", false)) {
            moveTaskToBack(true);
        }


    }

    private void loadUrl() {
        loadUrl(launchUrl);
        appView.clearCache();
    }


    @Override
    protected void onPause() {
        super.onPause();

        unRegisterReceiver();
        unbindService(frameworkServiceConnection);
    }

    @Override
    protected void onResume() {
        super.onResume();
        bindFrameworkService();
        setSystemUiVisibility();
        registerBarcodeScannerBroadcastReceiver();
        connectToServer();
    }

    private void connectToServer(){
        if (null==connectivityManager) {
            connectivityManager = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        }
        NetLinkStatusReceiver.NqNetType currType;
        NetworkInfo activeNetInfo = connectivityManager.getActiveNetworkInfo();
        if (activeNetInfo==null || !activeNetInfo.isConnected()) {
            currType = NetLinkStatusReceiver.NqNetType.NONE;
        } else {
            currType = nqNetTypeMap.get(activeNetInfo.getType());
            if (currType==null) {
                currType = NetLinkStatusReceiver.NqNetType.NONE;
            }
        }
        if (currType==lastConnectedNetType) {
            return;
        }
        lastConnectedNetType = currType;
        boolean isConnected = currType!= NetLinkStatusReceiver.NqNetType.NONE;
        if (isConnected) {
            loadUrl();
        }
    }

    private void setSystemUiVisibility (){
        getWindow().getDecorView()
                .setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        |View.SYSTEM_UI_FLAG_FULLSCREEN
                        |View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        |View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        |View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        |View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private void enablePersistentImmersiveMode(boolean enable) {
        if (frameworkAidlInterface != null) {
            try {
                frameworkAidlInterface.enablePersistentImmersiveMode(enable);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    private void bindFrameworkService() {
        Intent intent = new Intent("com.nlscan.nquireprogramservice.aidl.framework");
        intent.setPackage("com.nlscan.nquireprogramservice");
        bindService(intent, frameworkServiceConnection, BIND_AUTO_CREATE);
    }

    private void registerBarcodeScannerBroadcastReceiver() {
        //Enable the Output via API mode; do not add a line feed; turn Good Read LED on
        Intent intent = new Intent ("ACTION_BAR_SCANCFG");
        intent.putExtra("EXTRA_SCAN_MODE", 3);
        intent.putExtra("EXTRA_SCAN_AUTOENT", 0);
        intent.putExtra("EXTRA_SCAN_NOTY_LED", 1);
        sendBroadcast(intent);
        registerReceiver();
    }

    private void registerReceiver() {
        if (!scanResultBroadcastFlag) {

            IntentFilter intFilter = new IntentFilter(SCANNER_RESULT);
            registerReceiver(scanResultReceiver, intFilter);
            Log.d(LOGCAT_TAG, "registerReceiver：scanResultReceiver");
            scanResultBroadcastFlag = true;
        }

        if (!netLinkBroadcastFlag) {

            IntentFilter intFilter = new IntentFilter(CONNECTIVITY_CHANGE);
            registerReceiver(netLinkStatusReceiver, intFilter);
            Log.d(LOGCAT_TAG, "registerReceiver：netLinkStatusReceiver");
            netLinkBroadcastFlag = true;
        }



    }

    private NetLinkStatusReceiver netLinkStatusReceiver = new NetLinkStatusReceiver(new OnNqNetConnectedListener(){
        @Override
        public void onNqNetConnected(boolean isConnected) {
            if(isConnected){
                loadUrl();
            }
        }
    });

    private BroadcastReceiver scanResultReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            String action = intent.getAction();
            Log.d(LOGCAT_TAG, "action：" + action);
            if (SCANNER_RESULT.equals(action)) {
                Log.d(LOGCAT_TAG, "intent data：" + intent.toString());
                final String scanResult_1 = intent.getStringExtra("SCAN_BARCODE1");
                final String scanStatus = intent.getStringExtra("SCAN_STATE");
                Log.d(LOGCAT_TAG, "scanResult_1：" + scanResult_1);
                if ("ok".equals(scanStatus)) {
                    if (!TextUtils.isEmpty(scanResult_1)) {
                        final String result = scanResult_1;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Log.d(LOGCAT_TAG,"result:"+result);
                                loadUrl("javascript:nlscan.plugins.barcodescanner.show('" + result + "')");
                            }
                        });
                    }
                }
            }
        }
    };

    private void unRegisterReceiver() {
        if (scanResultBroadcastFlag) {
            try {
                unregisterReceiver(scanResultReceiver);
                Log.d(LOGCAT_TAG, "unregisterReceiver：scanResultReceiver");
                scanResultBroadcastFlag = false;
            } catch (Exception e) {
            }
        }

        if (netLinkBroadcastFlag) {
            try {
                unregisterReceiver(netLinkStatusReceiver);
                Log.d(LOGCAT_TAG, "unregisterReceiver：netLinkStatusReceiver");
                netLinkBroadcastFlag = false;
            } catch (Exception e) {
            }
        }

    }

}
