package com.nlscan.pda;

/**
 * @author Alan
 * @Company nlscan
 * @date 2018/3/6 11:47
 * @Description:
 */
interface OnNqNetConnectedListener {
    void onNqNetConnected(boolean isConnected);
}
