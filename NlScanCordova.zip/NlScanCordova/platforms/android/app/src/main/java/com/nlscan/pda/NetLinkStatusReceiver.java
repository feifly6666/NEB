package com.nlscan.pda;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.SparseArray;

public class NetLinkStatusReceiver extends BroadcastReceiver {

    enum NqNetType {NONE, ETHERNET, WIFI/*, MOBILE*/}
    private ConnectivityManager connectivityManager = null;
    private OnNqNetConnectedListener onNqNetConnectedListener = null;
    private NqNetType lastConnectedNetType = NqNetType.NONE;
    private SparseArray<NqNetType> nqNetTypeMap = new SparseArray<>(3);
    {
        nqNetTypeMap.put(ConnectivityManager.TYPE_ETHERNET, NqNetType.ETHERNET);
        nqNetTypeMap.put(ConnectivityManager.TYPE_WIFI, NqNetType.WIFI);
        //nqNetTypeMap.put(ConnectivityManager.TYPE_MOBILE, NqNetType.MOBILE);
    }

    public NetLinkStatusReceiver(OnNqNetConnectedListener listener) {
        onNqNetConnectedListener = listener;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (null==connectivityManager) {
            connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        }
        NqNetType currType;
        NetworkInfo activeNetInfo = connectivityManager.getActiveNetworkInfo();
        if (activeNetInfo==null || !activeNetInfo.isConnected()) {
            currType = NqNetType.NONE;
        } else {
            currType = nqNetTypeMap.get(activeNetInfo.getType());
            if (currType==null) {
                currType = NqNetType.NONE;
            }
        }
        // 滤除同种网络的connected信息的重复上报
        if (currType==lastConnectedNetType) {
            return;
        }
        lastConnectedNetType = currType;
        boolean isConnected = currType!=NqNetType.NONE;
        if (onNqNetConnectedListener!=null) {
            onNqNetConnectedListener.onNqNetConnected(isConnected);
        }
    }
}
