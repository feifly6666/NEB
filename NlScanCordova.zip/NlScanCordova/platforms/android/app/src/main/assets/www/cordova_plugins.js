cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
  {
    "id": "nlscan-plugin-barcodescanner.BarcodeScanner",
    "file": "plugins/nlscan-plugin-barcodescanner/www/BarcodeScanner.js",
    "pluginId": "nlscan-plugin-barcodescanner",
    "clobbers": [
      "nlscan.plugins.barcodescanner"
    ]
  }
];
module.exports.metadata = 
// TOP OF METADATA
{
  "cordova-plugin-whitelist": "1.3.3",
  "nlscan-plugin-barcodescanner": "0.0.1"
};
// BOTTOM OF METADATA
});