package com.nlscan.pda.scandemo;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.text.TextUtils;
import android.util.Log;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.json.JSONArray;
import org.json.JSONException;

/**
 * Cordova plugin to interface with NLSCAN barcode scanners.
 */
public class BarcodeScanner extends CordovaPlugin {

    private BroadcastReceiver mReceiver;
    private Context context;
    private static String SCANNER_RESULT = "nlscan.action.SCANNER_RESULT";
    private static String SCANNER_TRIG = "nlscan.action.SCANNER_TRIG";
    private static final String Tag = "BarcodeScannerTag";
    private static boolean registeredTag = false;
    private Activity activity;

    @Override
    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
        super.initialize(cordova, webView);
        context = super.webView.getContext();
        this.activity = cordova.getActivity();
        registerReceiver();
    }


    @Override
    public boolean execute(String action, JSONArray para, CallbackContext callbackContext) throws JSONException {
        if (action.equals("scan")) {
            Log.d(Tag,"execute method is called");
            Intent intent = new Intent(SCANNER_TRIG);
            context.sendBroadcast(intent);
            callbackContext.success();
            return true;
        }
        return false;
    }


    private void registerReceiver() {
        if (!registeredTag) {
            mReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    String action = intent.getAction();
                    if (SCANNER_RESULT.equals(action)) {
                        final String scanResult_1 = intent.getStringExtra("SCAN_BARCODE1");
                        final String scanStatus = intent.getStringExtra("SCAN_STATE");
                        Log.d(Tag, "scanResult_1：" + scanResult_1);
                        if ("ok".equals(scanStatus)) {
                            if (!TextUtils.isEmpty(scanResult_1)) {
                                final String result = "ScanResult:" + scanResult_1;
                                activity.runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        webView.loadUrl("javascript:nlscan.plugins.BarcodeScanner.show('" + result + "')");
                                    }
                                });
                            }
                        }
                    }
                }
            };
            IntentFilter intFilter = new IntentFilter(SCANNER_RESULT);
            context.registerReceiver(mReceiver, intFilter);
            registeredTag = true;
        }

    }

    private void unRegisterReceiver() {
        if (registeredTag) {
            try {
                super.webView.getContext().unregisterReceiver(mReceiver);
                registeredTag = false;
            } catch (Exception e) {
            }
        }

    }

    @Override
    public void onPause(boolean multitasking) {
        super.onPause(multitasking);
        unRegisterReceiver();
    }

    @Override
    public void onResume(boolean multitasking) {
        super.onResume(multitasking);
//        registerReceiver();
    }
}
